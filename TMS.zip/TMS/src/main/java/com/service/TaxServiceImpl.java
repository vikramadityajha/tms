package com.service;

import com.model.UserClaim;

public class TaxServiceImpl implements TaxService{

	@Override
	public double calculateTax(UserClaim userClaim) {
		// TODO Auto-generated method stub
		return 0;
	}

}
